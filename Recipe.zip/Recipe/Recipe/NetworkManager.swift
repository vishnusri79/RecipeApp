

import Foundation

class NetworkManager {
    static let shared = NetworkManager()
    
    func fetchMeals(completion: @escaping (Result<[Meal], Error>) -> Void) {
        guard let url = URL(string: "https://www.themealdb.com/api/json/v1/1/filter.php?c=Dessert") else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidData))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let responseData = try decoder.decode(ResponseData.self, from: data)
                completion(.success(responseData.meals))
                return
            } catch {
                completion(.failure(error))
                return
            }
        }.resume()
    }
    
    
    func fetchMealDetailsFromAPI(for mealID: String, completion: @escaping (Result<Meal, Error>) -> Void) {
        guard let url = URL(string: "https://www.themealdb.com/api/json/v1/1/lookup.php?i=\(mealID)") else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.invalidData))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let responseData = try decoder.decode(ResponseData.self, from: data)
                if let meal = responseData.meals.first {
                    completion(.success(meal))
                    
                    return
                } else {
                    completion(.failure(NetworkError.invalidData))
                    return
                }
            } catch {
                completion(.failure(error))
                return
            }
        }.resume()
    }
    
    
}

enum NetworkError: Error {
    case invalidURL
    case invalidData
}
