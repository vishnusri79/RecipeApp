

import Foundation
import UIKit

class RecipeViewController: UIViewController, MealUpdateDelegate {
   
    
    
    var meal: Meal?
    
    
    @IBOutlet weak var mealTitle: UILabel!
    @IBOutlet weak var mealCategory: UILabel!
    @IBOutlet weak var mealThumb: UIImageView!
    
    @IBOutlet weak var ingredient1: UILabel!
    @IBOutlet weak var ingredient2: UILabel!
    @IBOutlet weak var ingredient3: UILabel!
    @IBOutlet weak var ingredient4: UILabel!
    @IBOutlet weak var ingredient5: UILabel!
    
    @IBOutlet weak var measure1: UILabel!
    @IBOutlet weak var measure2: UILabel!
    @IBOutlet weak var measure3: UILabel!
    @IBOutlet weak var measure4: UILabel!
    @IBOutlet weak var measure5: UILabel!
    @IBOutlet weak var instructions: UILabel!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
    }
    
    func updateMeal(meal: Meal) {
        self.meal = meal
        populateUI(with: meal)
    }
    
    func populateUI(with meal: Meal) {
        mealTitle.text = meal.strMeal
        mealCategory.text = meal.strCategory
        if let url = URL(string: meal.strMealThumb) {
            self.mealThumb.loadImage(from: url)
        }
        ingredient1.text = meal.strIngredient1
        ingredient2.text = meal.strIngredient2
        ingredient3.text = meal.strIngredient3
        ingredient4.text = meal.strIngredient4
        ingredient5.text = meal.strIngredient5
        measure1.text = meal.strMeasure1
        measure2.text = meal.strMeasure2
        measure3.text = meal.strMeasure3
        measure4.text = meal.strMeasure4
        measure5.text = meal.strMeasure5
        instructions.text = meal.strInstructions
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
