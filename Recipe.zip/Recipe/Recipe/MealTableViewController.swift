
import Foundation
import UIKit
import CoreData

class MealTableViewController: UITableViewController {
    
    var meals: [Meal] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchMeals()
    }
    
    
    weak var delegate: MealUpdateDelegate?
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meals.count
    }
    
    func fetchMeals() {
            CoreDataManager.shared.fetchMeals { result in
                switch result {
                case .success(let meals):
                    if !meals.isEmpty {
                        print("Meals loaded from Core Data")
                        self.meals = meals

                    } else {
                        self.fetchMealsFromAPI()
                    }
                case .failure(let error):
                    print("Error fetching meals: \(error)")
                }
            }
        }
        
        func fetchMealsFromAPI() {
            NetworkManager.shared.fetchMeals { result in
                switch result {
                case .success(let meals):
                    self.meals = meals
                    CoreDataManager.shared.saveMeals(meals)
                    DispatchQueue.main.sync {
                        self.tableView.reloadData()
                    }
                case .failure(let error):
                    print("Error fetching meals from API: \(error)")
                }
            }
        }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "MealTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MealTableViewCell else {
            fatalError("The dequeued cell is not an instance of MealTableViewCell")
        }
        
        let meal = meals[indexPath.row]
        cell.title.text = meal.strMeal
        cell.picture.image = UIImage(named: meal.strMealThumb)
        
        if let url = URL(string: meal.strMealThumb) {
                    cell.picture.loadImage(from: url)
        }
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailsSegue" {
            
            if let recipeView = segue.destination as? RecipeViewController {
                self.delegate = recipeView
                if let indexPath = self.tableView.indexPathForSelectedRow {
                    
                    let meal = meals[indexPath.row]
                    NetworkManager.shared.fetchMealDetailsFromAPI(for: meal.idMeal) { result in
                        switch result {
                        case .success(let mealDetails):
                            CoreDataManager.shared.updateMeal(withID: meal.idMeal, newMealInfo: mealDetails)
                            DispatchQueue.main.sync {
                                self.delegate?.updateMeal(meal: mealDetails)
                            }
                        case .failure(let error):
                            print("Error fetching meal details: \(error)")
                            // Handle error gracefully, e.g., show alert to the user
                        }
                    }
                }
            }
        }
    }


}



extension UIImageView {
    func loadImage(from url: URL, placeholder: UIImage? = nil) {
        image = placeholder
        
        URLSession.shared.dataTask(with: url) { [weak self] (data, response, error) in
            guard let self = self else { return }
            
            if let error = error {
                print("Image loading error: \(error)")
                return
            }
            
            guard let data = data, let image = UIImage(data: data) else {
                print("Invalid image data")
                return
            }
            
            DispatchQueue.main.async {
                self.image = image
            }
        }.resume()
    }
}
