
import Foundation
import CoreData

class CoreDataManager {
    static let shared = CoreDataManager()
    
    private init() {}
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MealEntity")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    func saveContext() {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func saveMeals(_ meals: [Meal]) {
        let context = persistentContainer.viewContext
        for meal in meals {
            guard let entity = NSEntityDescription.entity(forEntityName: "MealEntity", in: context) else { continue }
            let mealEntity = MealEntity(entity: entity, insertInto: context)
            mealEntity.populate(from: meal)
        }
        saveContext()
    }
    
    func updateMeal(withID id: String, newMealInfo: Meal) {
        let context = persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<MealEntity> = MealEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "idMeal == %@", id)
        
        do {
            let results = try context.fetch(fetchRequest)
            guard let existingMealEntity = results.first else {
                print("Meal with ID \(id) not found")
                return
            }
            
            // Update existing meal entity with new meal information
            existingMealEntity.populate(from: newMealInfo)
            
            // Save the context
            saveContext()
        } catch {
            print("Error updating meal: \(error)")
        }
    }

    
    func fetchMeals(completion: @escaping (Result<[Meal], Error>) -> Void) {
        let context = persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<MealEntity> = MealEntity.fetchRequest()
        
        do {
            let meals = try context.fetch(fetchRequest).map { $0.toMeal() }
            completion(.success(meals))
        } catch {
            completion(.failure(error))
        }
    }
}
