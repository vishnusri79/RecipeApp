
import Foundation
import UIKit

struct Meal : Decodable {
    var idMeal: String
    var strMeal: String
    var strMealThumb: String
    var strCategory: String?
    var strArea: String?
    var strInstructions: String?
    var strTags: String?
    var strIngredient1: String?
    var strIngredient2: String?
    var strIngredient3: String?
    var strIngredient4: String?
    var strIngredient5: String?
    var strIngredient6: String?
    var strIngredient7: String?
    var strIngredient8: String?
    var strIngredient9: String?
    var strIngredient10: String?
    var strMeasure1: String?
    var strMeasure2: String?
    var strMeasure3: String?
    var strMeasure4: String?
    var strMeasure5: String?
    var strMeasure6: String?
    var strMeasure7: String?
    var strMeasure8: String?
    var strMeasure9: String?
    var strMeasure10: String?
}

struct ResponseData : Decodable {
    var meals: [Meal]
}


extension MealEntity {
    func populate(from meal: Meal) {
        idMeal = meal.idMeal
        strMeal = meal.strMeal
        strMealThumb = meal.strMealThumb
        strCategory = meal.strCategory
        strArea = meal.strArea
        strInstructions = meal.strInstructions
        strTags = meal.strTags
        strIngredient1 = meal.strIngredient1
        strIngredient2 = meal.strIngredient2
        strIngredient3 = meal.strIngredient3
        strIngredient4 = meal.strIngredient4
        strIngredient5 = meal.strIngredient5
        strIngredient6 = meal.strIngredient6
        strIngredient7 = meal.strIngredient7
        strIngredient8 = meal.strIngredient8
        strIngredient9 = meal.strIngredient9
        strIngredient10 = meal.strIngredient10
        strMeasure1 = meal.strMeasure1
        strMeasure2 = meal.strMeasure2
        strMeasure3 = meal.strMeasure3
        strMeasure4 = meal.strMeasure4
        strMeasure5 = meal.strMeasure5
        strMeasure6 = meal.strMeasure6
        strMeasure7 = meal.strMeasure7
        strMeasure8 = meal.strMeasure8
        strMeasure9 = meal.strMeasure9
        strMeasure10 = meal.strMeasure10
        // Populate other properties similarly
    }
    
    func toMeal() -> Meal {
        return Meal(
            idMeal: self.idMeal ?? "",
            strMeal: self.strMeal ?? "",
            strMealThumb: self.strMealThumb ?? "",
            strCategory: self.strCategory,
            strArea: self.strArea,
            strInstructions: self.strInstructions,
            strTags: self.strTags,
            strIngredient1: self.strIngredient1,
            strIngredient2: self.strIngredient2,
            strIngredient3: self.strIngredient3,
            strIngredient4: self.strIngredient4,
            strIngredient5: self.strIngredient5,
            strIngredient6: self.strIngredient6,
            strIngredient7: self.strIngredient7,
            strIngredient8: self.strIngredient8,
            strIngredient9: self.strIngredient9,
            strIngredient10: self.strIngredient10,
            strMeasure1: self.strMeasure1,
            strMeasure2: self.strMeasure2,
            strMeasure3: self.strMeasure3,
            strMeasure4: self.strMeasure4,
            strMeasure5: self.strMeasure5,
            strMeasure6: self.strMeasure6,
            strMeasure7: self.strMeasure7,
            strMeasure8: self.strMeasure8,
            strMeasure9: self.strMeasure9,
            strMeasure10: self.strMeasure10
        )
    }
}
