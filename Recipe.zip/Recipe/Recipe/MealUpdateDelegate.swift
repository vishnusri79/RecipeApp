

import Foundation
protocol MealUpdateDelegate: AnyObject {
    func updateMeal(meal: Meal)    
    
}
